import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class Mobilbiru here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Mobilbiru extends Pendukung
{
    /**
     * Act - do whatever the Mobilbiru wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    
    int speed = 2;
    public void act()
    {
        Mobilbiru a = new Mobilbiru();
        Actor i = getOneIntersectingObject(Mobilbiru.class);
        move(speed);
        checkdouble(i);
        end();
    }
}
