import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class Car here.
 * 
 * @author (Manuel.u81) 
 * @version (a version number or a date)
 */
public class Car extends Actor
{
    int score = 0;
    public void act()
    {
        getWorld().showText("Score : " + score, 60, 30);
        checkKey();
        end();
        addscore();
    }

    public void checkKey () {
        if(Greenfoot.isKeyDown("up")){
            setLocation(getX(), getY()-2);
        }
        if(Greenfoot.isKeyDown("down")){
            setLocation(getX(), getY()+2);
        }
        if(Greenfoot.isKeyDown("left")){
            setLocation(getX()-2, getY());
        }
        if(Greenfoot.isKeyDown("right")){
            setLocation(getX()+2, getY());
        }
    }
    public void end(){
    if(isTouching(Mobilbiru.class)){
       getWorld().showText("Game Over \n Score : " + score, 300,300); 
       Greenfoot.stop();
    }
    }
    public void addscore(){
       if(isTouching(Koin.class)){
       score = score + 10 ;
       removeTouching(Koin.class);
    }
}
}
